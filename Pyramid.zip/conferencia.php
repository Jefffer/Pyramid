<!doctype html>
<html class="no-js" lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="apple-touch-icon" href="apple-touch-icon.png">
        <!-- Place favicon.ico in the root directory -->

        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/css?family=Open+Sans|Oswald|PT+Sans" rel="stylesheet">
        <link rel="stylesheet" href="css/lightbox.css">
        <link rel="stylesheet" href="css/normalize.css">
        <link rel="stylesheet" href="https://unpkg.com/leaflet@1.3.4/dist/leaflet.css" />
        <link rel="stylesheet" href="css/main.css">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
    </head>
    <body class="conferencia">
        <!--[if lt IE 8]>
            <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
        <![endif]-->

        <header class="side-header">
           <div class="hero">

             <div class="barra clearfix fixed">
               <div class="contenedor ">
                  <div class="logo">
                    <a href="index.html">
                      <img src="img/logo_inmo1.png" alt="Logo">
                    </a>
                     <!-- <h1 class="nombre-sitio-menu">Inmobiliaria BABEL</h1> -->
                  </div>

                  <div class="menu-movil">
                     <span></span>
                     <span></span>
                     <span></span>
                  </div>

                  <nav class="navegacion-principal clearfix">
                     <a href="index.html">Inicio</a>
                     <a href="#como_funciona">¿Cómo funciona?</a>
                     <a href="index.html#nuestros_servicios">Servicios</a>
                     <a href="registro.html">Contáctanos</a>
                     <a href="#">Iniciar Sesión</a>
                  </nav>
               </div><!--.contenedor-->
            </div><!--.barra-->


             <div class="contenido-header">
                <nav class="redes-sociales">
                   <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                   <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                   <!-- <a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a> -->
                   <!-- <a href="#"><i class="fa fa-play-circle" aria-hidden="true"></i></a> -->
                   <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                </nav>
                   <div class="informacion-evento">
                      <!-- <div class="clearfix">
                        <p class="fecha"><i class="fa fa-calendar" aria-hidden="true"></i> 10 - 12 Diciembre</p>
                        <p class="ciudad">Madrid, Cundinamarca <i class="fa fa-map-marker" aria-hidden="true"></i></p>
                      </div> -->
                      <br>

                      <h1 class="nombre-sitio">Inmobiliaria PYRAMID</h1>
                      <p class="slogan">Tus soluciones inmobiliarias <span>al instante</span></p>
                   </div><!--.informacion-evento-->
                </div><!--.contenido-header-->
             </div><!--.hero-->
        </header>

        <section class="seccion contenedor">
           <h2>¿Cómo funciona?</h2>
           <p>
             <b>Inmobiliaria Pyramid</b> nace como respuesta a las diferentes inquietudes presentadas en el mercado inmobiliario. Gracias a nuestra constante innovación en diferentes estrategias de negociación y marketing buscamos resolverlas de manera rápida y eficiente, cambiando el concepto de compra-venta y alquiler en una manera más sencilla de intercambiar y utilizar tus bienes.
            </p>
       </section><!--.section-->       

       <section class="seccion contenedor padding_top_0">
       	<h2>Galería de Fotos</h2>
       	<div class="galeria">
       		<a href="img/galeria/01.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/01.jpg">
       		</a>
       		<a href="img/galeria/02.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/02.jpg">
       		</a>
       		<a href="img/galeria/03.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/03.jpg">
       		</a>
       		<a href="img/galeria/04.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/04.jpg">
       		</a>
       		<a href="img/galeria/05.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/05.jpg">
       		</a>
       		<a href="img/galeria/06.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/06.jpg">
       		</a>
       		<a href="img/galeria/07.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/07.jpg">
       		</a>
       		<a href="img/galeria/08.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/08.jpg">
       		</a>
       		<a href="img/galeria/09.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/09.jpg">
       		</a>
       		<a href="img/galeria/10.jpg" data-lightbox="galeria">
       			<img src="img/galeria/thumbs/10.jpg">
       		</a>

       	</div>

       </section>

       <footer class="site-footer">
          <div class="contenedor clearfix">
             <div class="footer-informacion">
                <h3>Sobre <span>Conference of Thrones</span></h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pa</p>
             </div>
             <div class="ultimos-tweets">
                <h3>Últimos <span>tweets</span></h3>
                <ul>
                   <li>Sed do eiusmod tempor incm veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex</li>
                   <li>Sed do eiusmod tempor  et dolore  minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex</li>
                   <li>Sed do eiusmod t ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex</li>
                </ul>
             </div>
             <div class="menu">
                <h3>Redes <span>Sociales</span></h3>
                <nav class="redes-sociales">
                 <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                 <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                 <a href="#"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
                 <a href="#"><i class="fa fa-play-circle" aria-hidden="true"></i></a>
                 <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
              </nav>
             </div>
          </div>

          <p class="copyright">Todos los derechos reservados - Conference of Thrones 2017 &copy</p>

       </footer>


        <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/vendor/jquery-1.12.0.min.js"><\/script>')</script>
        <script src="js/plugins.js"></script>
        <script src="js/jquery.animateNumber.min.js"></script>        
        <script src="https://unpkg.com/leaflet@1.3.4/dist/leaflet.js"></script>
        <script src="js/lightbox.js"></script>
        <script src="js/jquery.countdown.min.js"></script>
        <script src="js/jquery.lettering.js"></script>
        <script src="js/main.js"></script>

        <!-- Google Analytics: change UA-XXXXX-X to be your site's ID. -->
        <script>
            (function(b,o,i,l,e,r){b.GoogleAnalyticsObject=l;b[l]||(b[l]=
            function(){(b[l].q=b[l].q||[]).push(arguments)});b[l].l=+new Date;
            e=o.createElement(i);r=o.getElementsByTagName(i)[0];
            e.src='https://www.google-analytics.com/analytics.js';
            r.parentNode.insertBefore(e,r)}(window,document,'script','ga'));
            ga('create','UA-XXXXX-X','auto');ga('send','pageview');
        </script>
    </body>
</html>
