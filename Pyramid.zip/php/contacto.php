<?php
  $_POST['nombre'];
?>