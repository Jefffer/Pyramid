 <!--  <a href="https://api.whatsapp.com/send?phone=51955081075&text=Hola%21%20Quisiera%20m%C3%A1s%20informaci%C3%B3n%20sobre%20Varela%202." class="floatwhatsapp" target="_blank">
    <i class="fab fa-whatsapp my-float-whatsapp"></i>
  </a> -->
<div id="wppDiv"></div>

  <footer class="site-footer">
    <div class="contenedor clearfix">
     <div class="footer-informacion">
      <h3>Comunícate con <span>Nosotros</span></h3>
      <p><span>Angélica Pineda</span> <br>
        <i class="far fa-envelope"></i> angelica.p@viatainmobiliaria.com &nbsp;&nbsp;<i class="fab fa-whatsapp"></i> 311 2868539 
      </p>
      <p><span>Alexander Pineda</span> <br>
        <i class="far fa-envelope"></i> alexander.p@viatainmobiliaria.com &nbsp;&nbsp;<i class="fab fa-whatsapp"></i> 313 3655012 
      </p>
      <p><span>Jefferson Rodríguez</span> <br>
        <i class="far fa-envelope"></i> jefferson.r@viatainmobiliaria.com &nbsp;&nbsp;<i class="fab fa-whatsapp"></i> 313 3714054
      </p>
    </div>
    <div class="ultimos-tweets">
      <!--<h3>Últimos <span>tweets</span></h3>-->
      <ul>
        <a class="twitter-timeline" data-lang="es" data-height="200" data-theme="dark" data-link-color="#b92828" href="https://twitter.com/Viatainmobi?ref_src=twsrc%5Etfw">Tweets by Viatainmobi</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
       <!--
       <li>Sed do eiusmod tempor incm veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex</li>
       <li>Sed do eiusmod tempor  et dolore  minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex</li>
       <li>Sed do eiusmod t ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex</li>
       -->
     </ul>
   </div>
   <div class="menu footer-informacion">
    <h3><span>Síguenos</span> en</h3>
    <nav class="redes-sociales">
     <a href="https://www.facebook.com/viatainmobiliaria"><i class="fab fa-facebook" aria-hidden="true"></i></a>
     <a href="https://twitter.com/Viatainmobi"><i class="fab fa-twitter" aria-hidden="true"></i></a>
     <!--<a href="#"><i class="fab fa-youtube" aria-hidden="true"></i></a>-->
     <a href="https://www.instagram.com/viatainmobiliaria"><i class="fab fa-instagram" aria-hidden="true"></i></a>
   </nav>
   <h3>Políticas de <span>Privacidad</span></h3>
    <nav class="redes-sociales">
      <p>Conoce nuestras políticas de tratamiento de datos <a href="politicas_privacidad.php" target="_blank" class="estilos_links">aquí</a></p>
   </nav>
 </div>
</div>

<p class="copyright">vîata Inmobiliaria - Bogotá, Colombia 2019 Nit. 901302616 .: Developed by Jefffer</p>
</footer>
